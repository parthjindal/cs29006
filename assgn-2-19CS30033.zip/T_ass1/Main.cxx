/************ C++ Headers ************************************/
#include <iostream>
using namespace std;

/************ PROJECT Headers ********************************/
#include "Fraction.hxx"

void TestFraction();

int main()
{
    TestFraction();
    return 0;
}