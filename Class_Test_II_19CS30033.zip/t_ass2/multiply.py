def multiply(*args):
    ans = 1
    for i in args:
        ans *= i
    print(ans)


if __name__ == '__main__':
    multiply(3,4)
    multiply(3,4,5)
    multiply(3,4,5,6)

