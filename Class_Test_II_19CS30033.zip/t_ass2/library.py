class Base:
    pass