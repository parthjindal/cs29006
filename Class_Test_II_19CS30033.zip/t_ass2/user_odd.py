from library import Base

class Derived(Base):
    def bar(self):
        return self.foo()
    

if __name__ == '__main__':
    assert(Derived().bar())
    d1 = Derived()
    d1.bar()