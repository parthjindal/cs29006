import numpy as np
from datetime import datetime
import random

import random
a = []
for i in range(0,100000):
    n = random.random()
    a.append(n)
x = datetime.now()
a = [x+1 for x in a]
y = datetime.now()
c = np.array(a)
z = datetime.now()
c = c+1
k = datetime.now()
print("time take in b:{}\ntime taken in d:{}".format(int((y-x).total_seconds() * 1000),int((k-z).total_seconds() * 1000)))